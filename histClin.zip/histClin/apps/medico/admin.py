from django.contrib import admin
from apps.medico.models import Medico



# Register your models here.
admin.site.register(Medico)